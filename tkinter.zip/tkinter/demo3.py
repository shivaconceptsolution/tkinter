import tkinter as tk
window = tk.Text()
window.pack()


window.mainloop()
